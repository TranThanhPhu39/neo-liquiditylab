"""Provider-independent domain models."""
